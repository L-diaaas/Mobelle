package com.example.mobelleprojeto

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.mobelleprojeto.R
import com.example.mobelleprojeto.R.id.btConvidado

class LoginScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login_screen)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val botaoConvidado = findViewById<Button>(R.id.btConvidado)
        botaoConvidado.setOnClickListener {
            irParaHome()
        }
    }

    private fun irParaHome() {
        val intentHome = Intent(this, Home::class.java)
        startActivity(intentHome)
    }
}

