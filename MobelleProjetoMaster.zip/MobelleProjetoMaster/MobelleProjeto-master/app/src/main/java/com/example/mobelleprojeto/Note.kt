package com.example.mobelleprojeto

import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class Note : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note)

        window.statusBarColor = ContextCompat.getColor(this, R.color.lila)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val btnBack = findViewById<ImageButton>(R.id.btnBackNote)
        btnBack.setOnClickListener {
            finish()
        }
    }
}
